<?php
    require('functions.php');
    print_r($_GET);
    print_r($_POST);

    date_default_timezone_set('America/Chicago');
    echo '<p>' .date('l jS \of F Y h:i:s A'). '</p>';
?>
    <html>
        </head>
            <link rel="stylesheet" href="style.css">
        </head>

        <body> 
                <h2>Kaden Marshall</h2>


                <table>
                    <tr>
                        <th>Player 1 Main Deck</th>
                        <th>Player 1 Side Deck</th>
                        <th>Player 2 Main Deck</th>
                        <th>Player 2 Side Deck</th>
                    </tr>
                        <td><?= main_roll(); ?></td>
                        <td><?= side_roll(),",", side_roll(),",", side_roll() ?></td>
                        <td><?= main_roll(); ?></td>
                        <td><?= side_roll(),",", side_roll(),",", side_roll() ?></td>
                    </tr>
                    </table>

                <form action="/index.php" method="post";>
                    <label for ="Hit">Player1 Bet</label>
                        <input type="text" P1Bet= "Hit">

                    <input type= "Submit" name="P1Hit" value="Hit">
                        <input type= "Submit" name="P1Stand" value="Stand">
        
                    <label for ="Bet">Player2 Bet:</label>
                        <input type="text" P2Bet= "Bet">

                    <input type= "Submit" name="P2Hit" value="Hit">
                        <input type= "Submit" name="P2Stand" value="Stand">

                </form>

                <form action="/index.php" method="post";>
                    <input type= "reset" name ="reset" value="Reset">
                </form>




            <?php

                if (!empty($_POST['P1Hit']['Hit']))
                {
                    echo "HIT";
                }
                elseif(!empty($_POST['P1Stand']['Stand']))
                {
                    echo 'STAND';
                }

                if (!empty($_POST['P2Hit']['Hit']))
                {
                    echo 'HIT';
                    
                }
                elseif(!empty($_POST['P2Stand']['Stand']))
                {
                    echo 'STAND';
                }

                if ($_SERVER["REQUEST_METHOD"] == "POST")
                {
                    if (isset($_POST['reset']))
                    {
                        $reset = $_POST['reset'];
                        if (empty($reset))
                        {
                            echo "";
                        }
                        else
                        {
                            echo "";
                        }
                    }
                }



            ?>
    

            
    </html>
