Hello for this project I am using Docker.

You need to download Docker from the Docker website and configure it to your system. This inclueds the docker-compose file.