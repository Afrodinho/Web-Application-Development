<?php
echo '<script type="text/javascript"> 
window.onload = function () { alert("You have arrived at the Homepage!");}
</script>';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kaden Marshall's Portfolio</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="what.css">
</head>
<body>
    <div>
        <div class="w3-top w3-bar w3-black">
            <a href="index.php" class="w3-bar-item w3-button">Home</a>
            <a href="about.php" class="w3-bar-item w3-button">About</a>
            <a href="contact.php" class="w3-bar-item w3-button">Contact</a>
            </div>
    </div>
    <h1>Welcome to my Portfolio</h1>
    <p>Hello my name is Kaden Marshall thank you for looking at my portfolio.</p>
    <img src="images/Columbia.png" alt="Where" width="600" height="600">
    
</body>
</html>